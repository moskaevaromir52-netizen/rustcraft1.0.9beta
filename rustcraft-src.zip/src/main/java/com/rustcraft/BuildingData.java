package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Хранит элементы построек (фундамент, стена и т.д.): владелец, уровень и блоки. */
public class BuildingData extends SavedData {

    public static class Piece {
        public final int id;
        public final UUID owner;
        public final int type;
        public int tier;
        public final Set<Long> blocks = new LinkedHashSet<>();
        public float hp;
        /** Игровое время постройки (-1 = неизвестно, у старых построек). */
        public long placed = -1;
        public long lastDamage = -100000;

        public Piece(int id, UUID owner, int type, int tier) {
            this.id = id;
            this.owner = owner;
            this.type = type;
            this.tier = tier;
            this.hp = StructureHealth.max(tier);
        }
    }

    private final Map<Integer, Piece> pieces = new HashMap<>();
    private final Map<Long, Integer> index = new HashMap<>();
    private int next = 1;

    public static BuildingData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(BuildingData::load, BuildingData::new, "rustcraft_building");
    }

    public Piece add(UUID owner, int type, int tier, List<BlockPos> blocks) {
        Piece p = new Piece(next++, owner, type, tier);
        for (BlockPos b : blocks) {
            long l = b.asLong();
            p.blocks.add(l);
            index.put(l, p.id);
        }
        pieces.put(p.id, p);
        setDirty();
        return p;
    }

    public List<Piece> all() {
        return new ArrayList<>(pieces.values());
    }

    public Piece at(BlockPos pos) {
        Integer id = index.get(pos.asLong());
        return id == null ? null : pieces.get(id);
    }

    public void removePos(BlockPos pos) {
        Integer id = index.remove(pos.asLong());
        if (id == null) return;
        Piece p = pieces.get(id);
        if (p != null) {
            p.blocks.remove(pos.asLong());
            if (p.blocks.isEmpty()) pieces.remove(id);
        }
        setDirty();
    }

    public void removePiece(Piece p) {
        for (long l : p.blocks) index.remove(l);
        pieces.remove(p.id);
        setDirty();
    }

    public static BuildingData load(CompoundTag tag) {
        BuildingData d = new BuildingData();
        d.next = Math.max(1, tag.getInt("next"));
        ListTag list = tag.getList("pieces", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            Piece p = new Piece(c.getInt("id"), c.getUUID("owner"), c.getInt("type"), c.getInt("tier"));
            if (c.contains("hp")) p.hp = c.getFloat("hp");
            if (c.contains("placed")) p.placed = c.getLong("placed");
            p.lastDamage = c.contains("lastDamage") ? c.getLong("lastDamage") : -100000;
            for (long l : c.getLongArray("blocks")) {
                p.blocks.add(l);
                d.index.put(l, p.id);
            }
            d.pieces.put(p.id, p);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("next", next);
        ListTag list = new ListTag();
        for (Piece p : pieces.values()) {
            CompoundTag c = new CompoundTag();
            c.putInt("id", p.id);
            c.putUUID("owner", p.owner);
            c.putInt("type", p.type);
            c.putInt("tier", p.tier);
            c.putFloat("hp", p.hp);
            c.putLong("placed", p.placed);
            c.putLong("lastDamage", p.lastDamage);
            List<Long> l = new ArrayList<>(p.blocks);
            long[] arr = new long[l.size()];
            for (int i = 0; i < arr.length; i++) arr[i] = l.get(i);
            c.putLongArray("blocks", arr);
            list.add(c);
        }
        tag.put("pieces", list);
        return tag;
    }
}
