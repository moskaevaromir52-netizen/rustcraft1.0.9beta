package com.rustcraft;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Клавиши Z (обвесы) и X (фонарь/лазер), зум прицела при приседе. */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        while (ClientKeys.ATTACH.consumeClick()) {
            if (mc.screen == null && p.getMainHandItem().getItem() instanceof GunItem) {
                mc.setScreen(new AttachmentScreen());
            }
        }
        while (ClientKeys.TOGGLE.consumeClick()) {
            if (p.getMainHandItem().getItem() instanceof GunItem) {
                RustNet.CHANNEL.sendToServer(new AttachPacket(AttachPacket.TOGGLE, ""));
            }
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        ItemStack held = e.getPlayer().getMainHandItem();
        if (!(held.getItem() instanceof GunItem)) return;
        float aim = GunAnimClient.aim();
        if (aim <= 0.0F) return;
        float z = Attachments.mods(held).zoom();
        if (z >= 1.0F) z = 0.9F;   // без прицела - лёгкое приближение через механику
        float t = aim * aim * (3.0F - 2.0F * aim);
        e.setNewFovModifier(e.getNewFovModifier() * (1.0F + (z - 1.0F) * t));
    }

    /** С оружием: ЛКМ = выстрел (не бьём и не ломаем), ПКМ = прицел (не взаимодействуем). */
    @SubscribeEvent
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !(mc.player.getMainHandItem().getItem() instanceof GunItem)) return;
        if (e.isAttack() || e.isUseItem()) {
            e.setCanceled(true);
            e.setSwingHand(false);
        }
    }

    /** Прячем обычный курсор, пока прицеливаемся. */
    @SubscribeEvent
    public static void onOverlayPre(RenderGuiOverlayEvent.Pre e) {
        if (e.getOverlay() == VanillaGuiOverlay.CROSSHAIR.type() && GunAnimClient.aim() > 0.3F
                && Minecraft.getInstance().player != null
                && Minecraft.getInstance().player.getMainHandItem().getItem() instanceof GunItem) {
            e.setCanceled(true);
        }
    }
}
