package com.rustcraft;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;

/**
 * Обвесы оружия из Rust. Слоты: прицел, дуло, подствольный (фонарь ИЛИ лазер, как в игре).
 * Множители: recoil/spread/damage/delay (delay < 1 = выше скорострельность), zoom - множитель FOV при прицеливании (присесть).
 */
public final class Attachment {
    public enum Slot {
        SIGHT, MUZZLE, UNDER;

        public String key() {
            return name().toLowerCase(Locale.ROOT);
        }

        public static Slot byKey(String k) {
            for (Slot s : values()) if (s.key().equals(k)) return s;
            return null;
        }
    }

    public enum Cls { PISTOL, SHOTGUN, SMG, RIFLE, LMG, HEAVY }

    public static final List<Attachment> ALL = new ArrayList<>();

    public final String id;
    public final Slot slot;
    public final EnumSet<Cls> classes;
    public float recoil = 1.0F;
    public float spread = 1.0F;
    public float damage = 1.0F;
    public float delay = 1.0F;
    public float zoom = 1.0F;
    public boolean silent;
    public boolean light;
    public boolean laser;

    private Attachment(String id, Slot slot, Cls... cls) {
        this.id = id;
        this.slot = slot;
        this.classes = EnumSet.noneOf(Cls.class);
        for (Cls c : cls) classes.add(c);
        ALL.add(this);
    }

    private Attachment mod(float recoil, float spread, float damage, float delay) {
        this.recoil = recoil;
        this.spread = spread;
        this.damage = damage;
        this.delay = delay;
        return this;
    }

    private Attachment zoom(float z) {
        this.zoom = z;
        return this;
    }

    private Attachment silent() {
        this.silent = true;
        return this;
    }

    public static Attachment byId(String id) {
        for (Attachment a : ALL) if (a.id.equals(id)) return a;
        return null;
    }

    private static final Cls[] SIGHTED = {Cls.SHOTGUN, Cls.SMG, Cls.RIFLE, Cls.LMG, Cls.HEAVY};
    private static final Cls[] MUZZLED = {Cls.PISTOL, Cls.SMG, Cls.RIFLE, Cls.LMG};
    private static final Cls[] ALLCLS = {Cls.PISTOL, Cls.SHOTGUN, Cls.SMG, Cls.RIFLE, Cls.LMG, Cls.HEAVY};

    static {
        // ---- прицелы
        new Attachment("simple_handmade_sight", Slot.SIGHT, SIGHTED).mod(1.0F, 0.95F, 1.0F, 1.0F).zoom(0.95F);
        new Attachment("holosight", Slot.SIGHT, SIGHTED).mod(1.0F, 0.80F, 1.0F, 1.0F).zoom(0.65F);
        new Attachment("scope_8x", Slot.SIGHT, Cls.RIFLE, Cls.LMG).mod(1.0F, 0.50F, 1.0F, 1.0F).zoom(0.25F);
        new Attachment("variable_scope", Slot.SIGHT, Cls.RIFLE).mod(1.0F, 0.50F, 1.0F, 1.0F).zoom(0.12F);
        // ---- дульные
        new Attachment("military_silencer", Slot.MUZZLE, MUZZLED).mod(0.85F, 0.80F, 0.90F, 1.0F).silent();
        new Attachment("oil_filter_silencer", Slot.MUZZLE, MUZZLED).mod(0.90F, 0.90F, 0.85F, 1.0F).silent();
        new Attachment("soda_can_silencer", Slot.MUZZLE, MUZZLED).mod(1.0F, 0.95F, 0.80F, 1.0F).silent();
        new Attachment("muzzle_brake", Slot.MUZZLE, MUZZLED).mod(0.70F, 1.50F, 0.95F, 1.0F);
        new Attachment("muzzle_boost", Slot.MUZZLE, MUZZLED).mod(0.95F, 1.0F, 0.90F, 0.90F);
        // ---- подствольные (в одном слоте: фонарь ИЛИ лазер)
        Attachment fl = new Attachment("weapon_flashlight", Slot.UNDER, ALLCLS);
        fl.light = true;
        Attachment ls = new Attachment("weapon_lasersight", Slot.UNDER, ALLCLS);
        ls.laser = true;
    }
}
