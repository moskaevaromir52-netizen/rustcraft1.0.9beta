package com.rustcraft;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;
import java.util.Map;

/** Обвесы на конкретном оружии (хранятся в NBT предмета) и их суммарные эффекты. */
public final class Attachments {
    public static final String TAG = "rust_att";

    private Attachments() {
    }

    public record Mods(float recoil, float spread, float damage, float delay, float zoom,
                       boolean silent, boolean light, boolean laser) {
        public int delay(int base) {
            return Math.max(1, Math.round(base * delay));
        }

        public static final Mods NONE = new Mods(1, 1, 1, 1, 1, false, false, false);
    }

    private static final Map<String, Attachment.Cls> CLASS = Map.ofEntries(
            Map.entry("eoka_pistol", Attachment.Cls.PISTOL), Map.entry("revolver", Attachment.Cls.PISTOL),
            Map.entry("python_revolver", Attachment.Cls.PISTOL), Map.entry("semi_auto_pistol", Attachment.Cls.PISTOL),
            Map.entry("m92_pistol", Attachment.Cls.PISTOL), Map.entry("prototype_17", Attachment.Cls.PISTOL),
            Map.entry("nailgun", Attachment.Cls.PISTOL),
            Map.entry("waterpipe_shotgun", Attachment.Cls.SHOTGUN), Map.entry("double_barrel_shotgun", Attachment.Cls.SHOTGUN),
            Map.entry("pump_shotgun", Attachment.Cls.SHOTGUN), Map.entry("spas12", Attachment.Cls.SHOTGUN),
            Map.entry("m4_shotgun", Attachment.Cls.SHOTGUN),
            Map.entry("custom_smg", Attachment.Cls.SMG), Map.entry("thompson", Attachment.Cls.SMG),
            Map.entry("mp5a4", Attachment.Cls.SMG),
            Map.entry("semi_auto_rifle", Attachment.Cls.RIFLE), Map.entry("m39_rifle", Attachment.Cls.RIFLE),
            Map.entry("lr300", Attachment.Cls.RIFLE), Map.entry("assault_rifle", Attachment.Cls.RIFLE),
            Map.entry("bolt_action_rifle", Attachment.Cls.RIFLE), Map.entry("l96_rifle", Attachment.Cls.RIFLE),
            Map.entry("m249", Attachment.Cls.LMG), Map.entry("hmlmg", Attachment.Cls.LMG),
            Map.entry("rocket_launcher", Attachment.Cls.HEAVY), Map.entry("mgl", Attachment.Cls.HEAVY),
            Map.entry("flamethrower", Attachment.Cls.HEAVY));

    public static String gunId(Item item) {
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(item);
        return k == null ? "" : k.getPath();
    }

    public static Attachment.Cls cls(Item gun) {
        return CLASS.get(gunId(gun));
    }

    /** Пистолеты и дробовики - 2 слота, остальные - 3. */
    public static List<Attachment.Slot> slots(Item gun) {
        Attachment.Cls c = cls(gun);
        if (c == null) return List.of();
        return switch (c) {
            case PISTOL -> List.of(Attachment.Slot.MUZZLE, Attachment.Slot.UNDER);
            case SHOTGUN, HEAVY -> List.of(Attachment.Slot.SIGHT, Attachment.Slot.UNDER);
            default -> List.of(Attachment.Slot.SIGHT, Attachment.Slot.MUZZLE, Attachment.Slot.UNDER);
        };
    }

    public static boolean fits(Item gun, Attachment a) {
        Attachment.Cls c = cls(gun);
        return c != null && slots(gun).contains(a.slot) && a.classes.contains(c);
    }

    private static CompoundTag tag(ItemStack gun) {
        CompoundTag t = gun.getTag();
        return t == null || !t.contains(TAG) ? null : t.getCompound(TAG);
    }

    public static Attachment get(ItemStack gun, Attachment.Slot s) {
        CompoundTag a = tag(gun);
        if (a == null || !a.contains(s.key())) return null;
        return Attachment.byId(a.getString(s.key()));
    }

    public static boolean isOn(ItemStack gun) {
        CompoundTag a = tag(gun);
        return a != null && a.getBoolean("on");
    }

    public static Mods mods(ItemStack gun) {
        CompoundTag t = tag(gun);
        if (t == null) return Mods.NONE;
        float recoil = 1, spread = 1, damage = 1, delay = 1, zoom = 1;
        boolean silent = false, light = false, laser = false;
        boolean on = t.getBoolean("on");
        for (Attachment.Slot s : Attachment.Slot.values()) {
            Attachment a = get(gun, s);
            if (a == null) continue;
            recoil *= a.recoil;
            spread *= a.spread;
            damage *= a.damage;
            delay *= a.delay;
            zoom *= a.zoom;
            silent |= a.silent;
            if (a.light && on) light = true;
            if (a.laser && on) {
                laser = true;
                recoil *= 0.80F;   // Rust: лазер даёт -20% отдачи и -25% разброса, пока включён
                spread *= 0.75F;
            }
        }
        return new Mods(recoil, spread, damage, delay, zoom, silent, light, laser);
    }

    // ---------------- серверные операции ----------------
    private static void give(Player p, Item item) {
        ItemStack s = new ItemStack(item);
        if (!p.getInventory().add(s)) p.drop(s, false);
    }

    private static void msg(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable(key, args), true);
    }

    public static void install(ServerPlayer p, String id) {
        ItemStack gun = p.getMainHandItem();
        Attachment a = Attachment.byId(id);
        if (a == null || !(gun.getItem() instanceof GunItem) || !fits(gun.getItem(), a)) return;
        Item item = ModItems.get(a.id);
        boolean creative = p.getAbilities().instabuild;
        if (!creative && InvUtil.count(p, item) < 1) return;

        Attachment old = get(gun, a.slot);
        CompoundTag t = gun.getOrCreateTagElement(TAG);
        if (old != null && !creative) give(p, ModItems.get(old.id));
        if (!creative) InvUtil.remove(p, item, 1);
        t.putString(a.slot.key(), a.id);
        if (a.slot == Attachment.Slot.UNDER) t.putBoolean("on", false);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_IRON,
                SoundSource.PLAYERS, 0.8F, 1.3F);
    }

    public static void remove(ServerPlayer p, String slotKey) {
        ItemStack gun = p.getMainHandItem();
        Attachment.Slot s = Attachment.Slot.byKey(slotKey);
        if (s == null || !(gun.getItem() instanceof GunItem)) return;
        Attachment a = get(gun, s);
        if (a == null) return;
        CompoundTag t = gun.getOrCreateTagElement(TAG);
        t.remove(s.key());
        if (s == Attachment.Slot.UNDER) t.putBoolean("on", false);
        if (!p.getAbilities().instabuild) give(p, ModItems.get(a.id));
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_IRON,
                SoundSource.PLAYERS, 0.8F, 0.9F);
    }

    public static void toggle(ServerPlayer p) {
        ItemStack gun = p.getMainHandItem();
        if (!(gun.getItem() instanceof GunItem)) return;
        Attachment u = get(gun, Attachment.Slot.UNDER);
        if (u == null) return;
        CompoundTag t = gun.getOrCreateTagElement(TAG);
        boolean on = !t.getBoolean("on");
        t.putBoolean("on", on);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LEVER_CLICK,
                SoundSource.PLAYERS, 0.6F, on ? 1.4F : 1.0F);
        msg(p, on ? "msg.rustcraft.att_on" : "msg.rustcraft.att_off",
                Component.translatable("item.rustcraft." + u.id));
    }
}
