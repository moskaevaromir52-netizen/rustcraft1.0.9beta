package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Невидимый источник света от фонаря на оружии. Сам исчезает, если его перестали обновлять. */
public class FlashLightBlock extends Block {
    public static final BooleanProperty FRESH = BooleanProperty.create("fresh");

    public FlashLightBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FRESH, true));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FRESH);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.empty();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moving) {
        if (!level.isClientSide) level.scheduleTick(pos, this, 4);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource rnd) {
        if (state.getValue(FRESH)) {
            level.setBlock(pos, state.setValue(FRESH, false), 2);
            level.scheduleTick(pos, this, 4);
        } else {
            level.removeBlock(pos, false);
        }
    }

    /** Поставить или продлить свет в точке (только в воздухе). */
    public static void light(ServerLevel level, BlockPos pos) {
        BlockState cur = level.getBlockState(pos);
        if (cur.is(ModBlocks.FLASH_LIGHT.get())) {
            if (!cur.getValue(FRESH)) level.setBlock(pos, cur.setValue(FRESH, true), 2);
        } else if (cur.isAir()) {
            level.setBlock(pos, ModBlocks.FLASH_LIGHT.get().defaultBlockState(), 2);
        }
    }
}
