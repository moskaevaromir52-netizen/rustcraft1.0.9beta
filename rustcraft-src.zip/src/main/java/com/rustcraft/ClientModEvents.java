package com.rustcraft;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.item.Item;

/** Клиентские события MOD-шины: клавиши, модели оружия/обвесов, оверлей прицела. */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {
    }

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent e) {
        e.register(ClientKeys.ATTACH);
        e.register(ClientKeys.TOGGLE);
    }

    @SubscribeEvent
    public static void onModels(ModelEvent.RegisterAdditional e) {
        for (RegistryObject<Item> ro : ModItems.WEAPONS) {
            Item it = ro.get();
            if (!(it instanceof GunItem)) continue;
            String id = Attachments.gunId(it);
            e.register(GunRenderer.model(id + "_icon"));
            e.register(GunRenderer.model(id + "_fp"));
            e.register(GunRenderer.model(id + "_tp"));
            for (Attachment a : Attachment.ALL) {
                if (Attachments.fits(it, a)) e.register(GunRenderer.model("att/" + id + "_" + a.id));
            }
        }
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("scope", (gui, g, pt, w, h) -> renderScope(g, w, h));
    }

    private static void renderScope(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !mc.options.getCameraType().isFirstPerson()) return;
        ItemStack held = mc.player.getMainHandItem();
        if (!(held.getItem() instanceof GunItem) || GunAnimClient.aim() < 0.85F) return;
        Attachment sight = Attachments.get(held, Attachment.Slot.SIGHT);
        if (sight == null) return;
        int cx = w / 2;
        int cy = h / 2;
        switch (sight.id) {
            case "holosight" -> {
                g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFF2020);
                g.fill(cx - 7, cy, cx - 4, cy + 1, 0x99FF2020);
                g.fill(cx + 4, cy, cx + 7, cy + 1, 0x99FF2020);
                g.fill(cx, cy - 7, cx + 1, cy - 4, 0x99FF2020);
                g.fill(cx, cy + 4, cx + 1, cy + 7, 0x99FF2020);
            }
            case "simple_handmade_sight" -> {
                g.fill(cx - 1, cy - 12, cx + 1, cy - 3, 0xFF111111);
                g.fill(cx - 12, cy + 4, cx - 5, cy + 6, 0xFF111111);
                g.fill(cx + 5, cy + 4, cx + 12, cy + 6, 0xFF111111);
            }
            default -> {   // 8x и переменный зум: чёрное кольцо и перекрестие
                int r = (int) (Math.min(w, h) * 0.46F);
                for (int y = 0; y < h; y++) {
                    int dy = y - cy;
                    if (Math.abs(dy) >= r) {
                        g.fill(0, y, w, y + 1, 0xFF000000);
                    } else {
                        int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
                        g.fill(0, y, cx - half, y + 1, 0xFF000000);
                        g.fill(cx + half, y, w, y + 1, 0xFF000000);
                    }
                }
                g.fill(cx - r, cy, cx + r, cy + 1, 0xCC000000);
                g.fill(cx, cy - r, cx + 1, cy + r, 0xCC000000);
                g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFF2020);
            }
        }
    }
}
