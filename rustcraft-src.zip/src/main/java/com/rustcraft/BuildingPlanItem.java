package com.rustcraft;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * План строительства. ПКМ - построить выбранный элемент, Shift+ПКМ - сменить элемент.
 * Строит элементы из хвороста (twig); улучшаются киянкой (Hammer): дерево, камень, металл, бронированный.
 */
public class BuildingPlanItem extends Item {

    public BuildingPlanItem(Properties props) {
        super(props);
    }

    public static BuildingPlanner.Kind selected(ItemStack stack) {
        BuildingPlanner.Kind[] ks = BuildingPlanner.Kind.values();
        int i = stack.hasTag() ? stack.getTag().getInt("piece") : 0;
        return ks[Math.floorMod(i, ks.length)];
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        BuildingPlanner.Kind[] ks = BuildingPlanner.Kind.values();
        if (sp.isShiftKeyDown()) {
            int next = (selected(stack).ordinal() + 1) % ks.length;
            stack.getOrCreateTag().putInt("piece", next);
            BuildingPlanner.Kind k = ks[next];
            sp.displayClientMessage(Component.literal("§6План: §f" + k.title + " §7(" + BuildingPlanner.unitsFor(k, StructureHealth.TWIG)
                    + " " + BuildingPlanner.MATERIAL_NAMES[StructureHealth.TWIG] + ")"), true);
        } else {
            String error = BuildingPlanner.place(sp, selected(stack));
            if (error != null) {
                sp.displayClientMessage(Component.literal("§c" + error), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
