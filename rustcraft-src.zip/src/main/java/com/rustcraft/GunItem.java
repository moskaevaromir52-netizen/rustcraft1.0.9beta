package com.rustcraft;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.client.model.HumanoidModel;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

/**
 * Огнестрельное оружие. Стрельба мгновенная (hitscan), патроны берутся из инвентаря.
 * Автоматическое оружие стреляет, пока зажата правая кнопка мыши.
 */
public class GunItem extends Item {

    public enum Snd { PISTOL, RIFLE, SHOTGUN, SNIPER, NAIL, LAUNCHER, FLAME }

    public enum Mode { BULLET, EXPLOSIVE, FLAME }

    /**
     * @param damage  урон одной пули (для EXPLOSIVE не используется)
     * @param delay   задержка между выстрелами в тиках
     * @param auto    true - стрельба очередью при удержании ПКМ
     * @param ammoId  id предмета-патрона из мода
     * @param pellets число дробинок за выстрел
     * @param spread  разброс
     * @param range   дальность в блоках
     * @param power   сила взрыва (EXPLOSIVE)
     * @param recoil  отдача: на сколько градусов подбрасывает прицел вверх при выстреле
     */
    public record Stats(float damage, int delay, boolean auto, String ammoId, int pellets,
                        float spread, double range, Snd sound, Mode mode, float power, float recoil) {
    }

    private final Stats stats;

    public GunItem(Properties props, Stats stats) {
        super(props);
        this.stats = stats;
    }

    public Stats stats() {
        return stats;
    }

    /** В третьем лице игрок держит оружие двумя руками на уровне глаз. */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
                return HumanoidModel.ArmPose.CROSSBOW_HOLD;
            }

            @Override
            public net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer getCustomRenderer() {
                return GunRenderer.instance();
            }
        });
    }

    public Item ammoItem() {
        return ModItems.get(stats.ammoId());
    }

    /** Фонарь и лазер на оружии в руке. */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !selected || !(entity instanceof Player p) || p.tickCount % 2 != 0) return;
        Attachments.Mods m = Attachments.mods(stack);
        if (!m.light() && !m.laser()) return;
        ServerLevel sl = (ServerLevel) level;
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double max = m.light() ? 28.0 : 80.0;
        Vec3 end = eye.add(look.scale(max));
        BlockHitResult bh = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 hit = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
        double dist = hit.distanceTo(eye);
        if (m.light()) {
            for (double d : new double[]{Math.min(4.0, dist * 0.5), Math.max(0.5, dist - 0.4)}) {
                FlashLightBlock.light(sl, BlockPos.containing(eye.add(look.scale(d))));
            }
        }
        if (m.laser()) {
            Vec3 dot = hit.subtract(look.scale(0.05));
            sl.sendParticles(new net.minecraft.core.particles.DustParticleOptions(new org.joml.Vector3f(1.0F, 0.05F, 0.05F), 0.8F),
                    dot.x, dot.y, dot.z, 1, 0, 0, 0, 0);
        }
    }

    /** Смена обвеса не должна перезапускать анимацию доставания. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    /** ПКМ - только прицеливание (на клиенте), выстрел идёт по ЛКМ через FirePacket. */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }

    /** Вызывается сервером, когда клиент прислал выстрел. */
    public void fire(ServerLevel level, Player p, ItemStack stack, boolean aiming) {
        p.getPersistentData().putBoolean("rust_aim", aiming);
        tryShoot(level, p, stack);
    }

    // ---------- патроны ----------
    /** Есть ли чем стрелять (на клиенте тоже работает - инвентарь синхронизирован). */
    public boolean hasAmmo(Player p) {
        return p.getAbilities().instabuild || countAmmo(p) > 0;
    }

    private int countAmmo(Player p) {
        Item ammo = ammoItem();
        int n = 0;
        for (ItemStack s : p.getInventory().items) if (s.is(ammo)) n += s.getCount();
        for (ItemStack s : p.getInventory().offhand) if (s.is(ammo)) n += s.getCount();
        return n;
    }

    private void takeAmmo(Player p) {
        Item ammo = ammoItem();
        for (ItemStack s : p.getInventory().items) {
            if (s.is(ammo)) {
                s.shrink(1);
                return;
            }
        }
        for (ItemStack s : p.getInventory().offhand) {
            if (s.is(ammo)) {
                s.shrink(1);
                return;
            }
        }
    }

    // ---------- выстрел ----------
    private void tryShoot(ServerLevel level, Player p, ItemStack stack) {
        Attachments.Mods mods = Attachments.mods(stack);
        long now = level.getGameTime();
        CompoundTag data = p.getPersistentData();
        if (now - data.getLong("rust_last_shot") < mods.delay(stats.delay())) return;
        data.putLong("rust_last_shot", now);

        boolean creative = p.getAbilities().instabuild;
        if (!creative && countAmmo(p) <= 0) {
            p.displayClientMessage(Component.literal("§cНет патронов"), true);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.DISPENSER_FAIL,
                    SoundSource.PLAYERS, 0.6F, 1.5F);
            return;
        }
        if (!creative) {
            // огнемёт тратит 1 топливо примерно на 8 выстрелов
            if (stats.mode() != Mode.FLAME || level.random.nextInt(8) == 0) {
                takeAmmo(p);
            }
            p.displayClientMessage(Component.literal("§e" + countAmmo(p) + " патр."), true);
        }

        playSound(level, p, mods);
        switch (stats.mode()) {
            case FLAME -> flame(level, p);
            default -> shootBullets(level, p, mods);
        }
    }

    private void playSound(ServerLevel level, Player p, Attachments.Mods mods) {
        SoundEvent ev;
        float vol = 1.0F;
        float pitch = 1.0F + (level.random.nextFloat() - 0.5F) * 0.1F;
        switch (stats.sound()) {
            case PISTOL -> {
                ev = SoundEvents.FIREWORK_ROCKET_BLAST;
                pitch += 0.3F;
            }
            case RIFLE -> ev = SoundEvents.FIREWORK_ROCKET_LARGE_BLAST;
            case SHOTGUN -> {
                ev = SoundEvents.GENERIC_EXPLODE;
                vol = 0.5F;
                pitch += 0.4F;
            }
            case SNIPER -> {
                ev = SoundEvents.GENERIC_EXPLODE;
                vol = 0.7F;
                pitch += 0.6F;
            }
            case NAIL -> {
                ev = SoundEvents.DISPENSER_LAUNCH;
                pitch += 0.4F;
            }
            case LAUNCHER -> {
                ev = SoundEvents.FIREWORK_ROCKET_LAUNCH;
                vol = 1.5F;
                pitch -= 0.3F;
            }
            default -> {
                ev = SoundEvents.FIRECHARGE_USE;
                vol = 0.6F;
            }
        }
        if (mods.silent()) {   // глушитель: тихий хлопок
            vol *= 0.12F;
            pitch += 0.5F;
        }
        level.playSound(null, p.getX(), p.getY(), p.getZ(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    private void shootBullets(ServerLevel level, Player p, Attachments.Mods mods) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double range = stats.range();

        Vec3 muzzle = eye.add(look.scale(0.9));
        if (!mods.silent()) {
            level.sendParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y - 0.1, muzzle.z, 2, 0.02, 0.02, 0.02, 0.01);
        }
        // Rust: в прицеливании (присед) кучность лучше
        float spreadMul = mods.spread() * (p.getPersistentData().getBoolean("rust_aim") ? 0.6F : 1.0F);

        for (int i = 0; i < stats.pellets(); i++) {
            Vec3 dir = new Vec3(
                    look.x + level.random.nextGaussian() * stats.spread() * spreadMul,
                    look.y + level.random.nextGaussian() * stats.spread() * spreadMul,
                    look.z + level.random.nextGaussian() * stats.spread() * spreadMul).normalize();
            Vec3 end = eye.add(dir.scale(range));

            BlockHitResult bh = level.clip(new ClipContext(eye, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();

            // по бочкам можно стрелять
            if (bh.getType() == HitResult.Type.BLOCK && stats.mode() == Mode.BULLET) {
                BlockState hs = level.getBlockState(bh.getBlockPos());
                if (hs.getBlock() instanceof BarrelBlock
                        && level.random.nextFloat() < (stats.pellets() > 1 ? 0.2F : 0.5F)) {
                    BarrelBlock.hit(level, bh.getBlockPos(), hs, 1);
                }
            }

            AABB box = p.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0);
            EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, p, eye, stop, box,
                    e -> !e.isSpectator() && e.isPickable() && e != p);

            if (eh != null) {
                Entity target = eh.getEntity();
                stop = eh.getLocation();
                if (stats.mode() == Mode.BULLET && stats.damage() > 0) {
                    boolean head = stop.y > target.getEyeY() - 0.2;
                    float dmg = stats.damage() * mods.damage() * (head ? 1.5F : 1.0F);
                    if (target instanceof LivingEntity le) le.invulnerableTime = 0;
                    target.hurt(p.damageSources().playerAttack(p), dmg);
                }
            }

            if (stats.mode() == Mode.EXPLOSIVE) {
                // дымный след ракеты
                for (int k = 1; k < 12; k++) {
                    Vec3 t = eye.add(stop.subtract(eye).scale(k / 12.0));
                    level.sendParticles(ParticleTypes.FLAME, t.x, t.y, t.z, 1, 0.02, 0.02, 0.02, 0.0);
                    level.sendParticles(ParticleTypes.SMOKE, t.x, t.y, t.z, 1, 0.05, 0.05, 0.05, 0.0);
                }
                level.explode(p, stop.x, stop.y, stop.z, stats.power(), Level.ExplosionInteraction.TNT);
                StructureDamage.explode(level, stop, ammoItem() == ModItems.get("rocket")
                        ? StructureDamage.Source.ROCKET : StructureDamage.Source.GRENADE40, p);
            } else {
                level.sendParticles(ParticleTypes.CRIT, stop.x, stop.y, stop.z, 2, 0.05, 0.05, 0.05, 0.0);
            }
        }
    }

    private void flame(ServerLevel level, Player p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double range = stats.range();
        AABB box = p.getBoundingBox().expandTowards(look.scale(range)).inflate(2.0);
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 to = le.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist <= range && to.normalize().dot(look) > 0.85) {
                le.setSecondsOnFire(5);
                le.invulnerableTime = 0;
                le.hurt(p.damageSources().playerAttack(p), 1.5F);
            }
        }
        for (int i = 0; i < 7; i++) {
            double d = 1.0 + i * (range / 8.0);
            level.sendParticles(ParticleTypes.FLAME, eye.x + look.x * d, eye.y - 0.2 + look.y * d,
                    eye.z + look.z * d, 3, 0.15, 0.15, 0.15, 0.01);
        }
    }
}
