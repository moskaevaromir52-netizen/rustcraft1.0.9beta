package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Аирдроп с лутом, как в Rust. */
public class Airdrop {
    public static void drop(ServerLevel level, BlockPos near) {
        RandomSource r = level.random;
        int x = near.getX() + r.nextInt(121) - 60;
        int z = near.getZ() + r.nextInt(121) - 60;
        level.getChunk(x >> 4, z >> 4);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);

        if (!level.getBlockState(pos.below()).isSolid()) {
            level.setBlock(pos.below(), Blocks.OAK_PLANKS.defaultBlockState(), 3);
        }
        level.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3);

        if (level.getBlockEntity(pos) instanceof ChestBlockEntity chest) {
            List<ItemStack> loot = new ArrayList<>(List.of(
                    new ItemStack(ModItems.SCRAP.get(), 10 + r.nextInt(20)),
                    new ItemStack(ModItems.BANDAGE.get(), 2 + r.nextInt(4)),
                    new ItemStack(Items.IRON_INGOT, 8 + r.nextInt(17)),
                    new ItemStack(Items.COOKED_BEEF, 6),
                    new ItemStack(Items.BOW),
                    new ItemStack(Items.ARROW, 16 + r.nextInt(33)),
                    new ItemStack(Items.IRON_CHESTPLATE),
                    new ItemStack(Items.IRON_SWORD),
                    new ItemStack(Items.GOLDEN_APPLE, 2)));
            Collections.shuffle(loot, new java.util.Random(r.nextLong()));
            List<ItemStack> picked = new ArrayList<>(loot.subList(0, 4));

            // оружие, одежда и гранаты из RustCraft
            List<Item> guns = new ArrayList<>();
            List<Item> explosives = new ArrayList<>();
            List<Item> armor = new ArrayList<>();
            for (RegistryObject<Item> ro : ModItems.WEAPONS) {
                if (ro.get() instanceof GunItem) guns.add(ro.get());
                else if (ro.get() instanceof ThrowableExplosive) explosives.add(ro.get());
            }
            for (RegistryObject<Item> ro : ModItems.ARMOR) armor.add(ro.get());

            Item gun = guns.get(r.nextInt(guns.size()));
            picked.add(new ItemStack(gun));
            picked.add(new ItemStack(((GunItem) gun).ammoItem(), 20 + r.nextInt(41)));
            picked.add(new ItemStack(armor.get(r.nextInt(armor.size()))));
            picked.add(new ItemStack(explosives.get(r.nextInt(explosives.size())), 1 + r.nextInt(3)));

            // разные слоты, чтобы предметы не затирали друг друга
            List<Integer> slots = new ArrayList<>();
            for (int i = 0; i < 27; i++) slots.add(i);
            Collections.shuffle(slots, new java.util.Random(r.nextLong()));
            for (int i = 0; i < picked.size(); i++) {
                chest.setItem(slots.get(i), picked.get(i));
            }
        }

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(pos));
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.literal("§6[Airdrop] §fГруз сброшен около X: " + x + "  Z: " + z), false);
    }
}
