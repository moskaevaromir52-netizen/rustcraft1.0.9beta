package com.rustcraft;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Материалы брони Rust. Текстуры: assets/rustcraft/textures/models/armor/<name>_layer_1/2.png */
public enum RustArmorMaterial implements ArmorMaterial {
    //            имя        проч. боты ноги нагр шлем  зачар. стойк. отброс.  звук
    BURLAP("burlap", 5, 1, 1, 2, 1, 8, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_LEATHER),
    CLOTH("cloth", 6, 1, 1, 2, 1, 8, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_LEATHER),
    LEATHER("rleather", 10, 1, 2, 3, 1, 10, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_LEATHER),
    HIDE("hide", 8, 1, 2, 3, 1, 9, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_LEATHER),
    WOOD("wood", 10, 1, 2, 4, 2, 6, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_GENERIC),
    ROADSIGN("roadsign", 18, 2, 3, 5, 2, 9, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_IRON),
    METAL("metal", 25, 2, 4, 6, 3, 9, 1.0F, 0.0F, SoundEvents.ARMOR_EQUIP_IRON),
    BONE("bone", 15, 2, 3, 5, 2, 8, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_GENERIC),
    HEAVY("heavy", 36, 3, 6, 8, 3, 7, 2.0F, 0.1F, SoundEvents.ARMOR_EQUIP_NETHERITE),
    HAZMAT("hazmat", 15, 1, 2, 3, 1, 8, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_GENERIC),
    RIOT("riot", 20, 2, 3, 5, 3, 9, 0.5F, 0.0F, SoundEvents.ARMOR_EQUIP_IRON),
    WETSUIT("wetsuit", 8, 1, 1, 2, 1, 8, 0.0F, 0.0F, SoundEvents.ARMOR_EQUIP_LEATHER);

    private final String name;
    private final int durabilityMultiplier;
    private final int boots, legs, chest, helmet;
    private final int enchantability;
    private final float toughness;
    private final float knockbackResistance;
    private final SoundEvent sound;

    RustArmorMaterial(String name, int durabilityMultiplier, int boots, int legs, int chest, int helmet,
                      int enchantability, float toughness, float knockbackResistance, SoundEvent sound) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.boots = boots;
        this.legs = legs;
        this.chest = chest;
        this.helmet = helmet;
        this.enchantability = enchantability;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.sound = sound;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        int base = switch (type) {
            case HELMET -> 11;
            case CHESTPLATE -> 16;
            case LEGGINGS -> 15;
            case BOOTS -> 13;
        };
        return base * durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> helmet;
            case CHESTPLATE -> chest;
            case LEGGINGS -> legs;
            case BOOTS -> boots;
        };
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return sound;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }

    @Override
    public String getName() {
        return RustCraft.MODID + ":" + name;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
