package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Система строительства как в Rust. Постройка делится на элементы 3x3 блока,
 * привязанные к сетке мира (поэтому элементы сами стыкуются друг с другом).
 */
public final class BuildingPlanner {

    public enum Kind {
        FOUNDATION("Фундамент", 25),
        FLOOR("Перекрытие", 15),
        WALL("Стена", 15),
        DOORWAY("Дверной проём", 12),
        WINDOW("Стена с окном", 12),
        STAIRS("Лестница", 12);

        public final String title;
        public final int cost;

        Kind(String title, int cost) {
            this.title = title;
            this.cost = cost;
        }
    }

    public record Plan(List<BlockPos> blocks, String error) {
    }

    private BuildingPlanner() {
    }

    // ------------------------------------------------------------ материалы
    private static final double[] MULT = {1.0, 1.0, 0.6, 0.25, 1.0};
    public static final String[] MATERIAL_NAMES = {"досок", "булыжника", "металлических фрагментов", "металла высокого качества", "палок"};

    public static boolean isMaterial(ItemStack s, int tier) {
        return switch (tier) {
            case 0 -> s.is(ItemTags.PLANKS);
            case 1 -> s.is(Items.COBBLESTONE);
            case 2 -> s.is(ModItems.get("metal_fragments"));
            case 4 -> s.is(Items.STICK);
            default -> s.is(ModItems.get("hq_metal"));
        };
    }

    public static int unitsFor(Kind k, int tier) {
        return Math.max(2, (int) Math.round(k.cost * MULT[tier]));
    }

    public static int count(Player p, int tier) {
        int n = 0;
        for (ItemStack s : p.getInventory().items) if (isMaterial(s, tier)) n += s.getCount();
        return n;
    }

    public static void take(Player p, int tier, int amount) {
        for (ItemStack s : p.getInventory().items) {
            if (amount <= 0) return;
            if (isMaterial(s, tier)) {
                int t = Math.min(amount, s.getCount());
                s.shrink(t);
                amount -= t;
            }
        }
    }

    // ------------------------------------------------------------ проверки
    private static boolean isBuilding(Level level, BlockPos pos) {
        return level.getBlockState(pos).getBlock() instanceof BuildingBlock;
    }

    private static boolean airOnly(Level level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.isAir() || s.canBeReplaced();
    }

    private static boolean canOverwrite(Level level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        if (s.getBlock() instanceof BuildingBlock || s.hasBlockEntity()) return false;
        return s.getDestroySpeed(level, pos) >= 0;
    }

    private static boolean isWallType(int type) {
        return type == Kind.WALL.ordinal() || type == Kind.DOORWAY.ordinal() || type == Kind.WINDOW.ordinal();
    }

    private static Plan err(String m) {
        return new Plan(List.of(), m);
    }

    // ------------------------------------------------------------ расчёт
    public static Plan compute(Level level, Player p, Kind k) {
        if (!(level instanceof ServerLevel sl)) return err("");
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getLookAngle().scale(10));
        BlockHitResult hit = level.clip(new ClipContext(eye, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() == HitResult.Type.MISS) return err("Наведите на землю или постройку");

        BlockPos hp = hit.getBlockPos();
        Direction face = hit.getDirection();
        Vec3 loc = hit.getLocation();
        BuildingData.Piece hitPiece = BuildingData.get(sl).at(hp);

        Plan plan = switch (k) {
            case FOUNDATION -> foundation(level, hp, face);
            case FLOOR -> floor(level, hp, face);
            case WALL, DOORWAY, WINDOW -> wall(level, k, hp, face, loc, hitPiece);
            case STAIRS -> stairs(level, p, hp, face, hitPiece);
        };
        if (plan.error() != null) return plan;

        ClaimData claims = ClaimData.get(sl);
        for (BlockPos b : plan.blocks()) {
            if (!claims.canBuild(b, p.getUUID())) return err("Приватная территория (Tool Cupboard)");
        }
        return plan;
    }

    private static int cell(int v) {
        return Math.floorDiv(v, 3) * 3;
    }

    private static Plan foundation(Level level, BlockPos hp, Direction face) {
        BlockPos base = face == Direction.UP ? hp.above() : hp.relative(face);
        int cx = cell(base.getX()), cz = cell(base.getZ()), y = base.getY();
        List<BlockPos> out = new ArrayList<>();
        for (int dx = 0; dx < 3; dx++) {
            for (int dz = 0; dz < 3; dz++) {
                BlockPos b = new BlockPos(cx + dx, y, cz + dz);
                if (!canOverwrite(level, b)) return err("Место занято");
                out.add(b);
                // «ножки» фундамента до земли
                for (int d = 1; d <= 4; d++) {
                    BlockPos l = b.below(d);
                    if (airOnly(level, l)) out.add(l);
                    else break;
                }
            }
        }
        return new Plan(out, null);
    }

    private static Plan floor(Level level, BlockPos hp, Direction face) {
        BlockPos base = face == Direction.UP ? hp.above() : hp.relative(face);
        int cx = cell(base.getX()), cz = cell(base.getZ()), y = base.getY();
        List<BlockPos> out = new ArrayList<>();
        for (int dx = 0; dx < 3; dx++) {
            for (int dz = 0; dz < 3; dz++) {
                BlockPos b = new BlockPos(cx + dx, y, cz + dz);
                if (!airOnly(level, b)) return err("Место занято");
                out.add(b);
            }
        }
        boolean supported = false;
        for (int dx = -1; dx <= 3 && !supported; dx++) {
            for (int dz = -1; dz <= 3 && !supported; dz++) {
                BlockPos b = new BlockPos(cx + dx, y, cz + dz);
                boolean inside = dx >= 0 && dx < 3 && dz >= 0 && dz < 3;
                if (isBuilding(level, b.below()) || (!inside && isBuilding(level, b))) supported = true;
            }
        }
        if (!supported) return err("Перекрытие нужно ставить на стены или рядом с фундаментом");
        return new Plan(out, null);
    }

    private static Plan wall(Level level, Kind k, BlockPos hp, Direction face, Vec3 loc,
                             BuildingData.Piece hitPiece) {
        int baseY;
        int[] origin = new int[2]; // x, z начала стены
        boolean alongX;

        if (hitPiece != null && isWallType(hitPiece.type) && face == Direction.UP) {
            // вторая стена поверх первой
            int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minZ = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
            for (long l : hitPiece.blocks) {
                BlockPos b = BlockPos.of(l);
                minX = Math.min(minX, b.getX());
                maxX = Math.max(maxX, b.getX());
                minZ = Math.min(minZ, b.getZ());
                maxY = Math.max(maxY, b.getY());
            }
            baseY = maxY + 1;
            alongX = maxX - minX == 2;
            origin[0] = minX;
            origin[1] = minZ;
        } else {
            if (hitPiece != null && isWallType(hitPiece.type)) {
                return err("Наведите на верх стены или на фундамент/перекрытие");
            }
            int cx = cell(hp.getX()), cz = cell(hp.getZ());
            if (hitPiece != null) {
                int maxY = Integer.MIN_VALUE;
                for (long l : hitPiece.blocks) maxY = Math.max(maxY, BlockPos.of(l).getY());
                baseY = maxY + 1;
            } else {
                baseY = hp.getY() + 1;
            }
            Direction edge;
            if (face.getAxis().isHorizontal()) {
                edge = face;
            } else {
                double lx = loc.x - (cx + 1.5), lz = loc.z - (cz + 1.5);
                edge = Math.abs(lx) > Math.abs(lz)
                        ? (lx > 0 ? Direction.EAST : Direction.WEST)
                        : (lz > 0 ? Direction.SOUTH : Direction.NORTH);
            }
            switch (edge) {
                case NORTH -> {
                    alongX = true;
                    origin[0] = cx;
                    origin[1] = cz;
                }
                case SOUTH -> {
                    alongX = true;
                    origin[0] = cx;
                    origin[1] = cz + 2;
                }
                case WEST -> {
                    alongX = false;
                    origin[0] = cx;
                    origin[1] = cz;
                }
                default -> {
                    alongX = false;
                    origin[0] = cx + 2;
                    origin[1] = cz;
                }
            }
        }

        List<BlockPos> out = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            int x = alongX ? origin[0] + i : origin[0];
            int z = alongX ? origin[1] : origin[1] + i;
            if ((i == 0 || i == 2) && !isBuilding(level, new BlockPos(x, baseY - 1, z))) {
                return err("Стену нужно ставить на фундамент или перекрытие");
            }
            for (int dy = 0; dy < 3; dy++) {
                if (i == 1 && k == Kind.DOORWAY && dy <= 1) continue;
                if (i == 1 && k == Kind.WINDOW && dy == 1) continue;
                BlockPos b = new BlockPos(x, baseY + dy, z);
                if (!airOnly(level, b)) return err("Место занято");
                out.add(b);
            }
        }
        return new Plan(out, null);
    }

    private static Plan stairs(Level level, Player p, BlockPos hp, Direction face, BuildingData.Piece hitPiece) {
        int cx = cell(hp.getX()), cz = cell(hp.getZ());
        int baseY;
        if (hitPiece != null) {
            int maxY = Integer.MIN_VALUE;
            for (long l : hitPiece.blocks) maxY = Math.max(maxY, BlockPos.of(l).getY());
            baseY = maxY + 1;
        } else {
            baseY = hp.getY() + 1;
        }
        Direction dir = p.getDirection();
        List<BlockPos> out = new ArrayList<>();
        for (int r = 0; r < 3; r++) {
            for (int i = 0; i < 3; i++) {
                int x, z;
                switch (dir) {
                    case NORTH -> {
                        x = cx + i;
                        z = cz + 2 - r;
                    }
                    case SOUTH -> {
                        x = cx + i;
                        z = cz + r;
                    }
                    case EAST -> {
                        x = cx + r;
                        z = cz + i;
                    }
                    default -> {
                        x = cx + 2 - r;
                        z = cz + i;
                    }
                }
                if (r == 0 && !isBuilding(level, new BlockPos(x, baseY - 1, z))) {
                    return err("Лестницу нужно ставить на фундамент или перекрытие");
                }
                for (int h = 0; h <= r; h++) {
                    BlockPos b = new BlockPos(x, baseY + h, z);
                    if (!airOnly(level, b)) return err("Место занято");
                    out.add(b);
                }
            }
        }
        return new Plan(out, null);
    }

    // ------------------------------------------------------------ действия
    /** Зелёные/красные частицы-контур перед постройкой (видит только игрок). */
    public static void preview(ServerPlayer sp, Kind k) {
        Plan plan = compute(sp.level(), sp, k);
        ServerLevel sl = sp.serverLevel();
        boolean ok = plan.error() == null;
        DustParticleOptions dust = new DustParticleOptions(
                ok ? new Vector3f(0.2F, 1.0F, 0.3F) : new Vector3f(1.0F, 0.15F, 0.15F), 1.0F);
        if (!ok) return;
        for (BlockPos b : plan.blocks()) {
            sl.sendParticles(sp, dust, false, b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5,
                    1, 0.15, 0.15, 0.15, 0.0);
        }
    }

    /** @return текст ошибки или null, если элемент построен. */
    public static String place(ServerPlayer sp, Kind k) {
        Plan plan = compute(sp.level(), sp, k);
        if (plan.error() != null) return plan.error();

        boolean creative = sp.getAbilities().instabuild;
        int units = unitsFor(k, StructureHealth.TWIG);
        if (!creative && count(sp, StructureHealth.TWIG) < units) {
            return "Нужно " + units + " " + MATERIAL_NAMES[StructureHealth.TWIG] + " (есть " + count(sp, StructureHealth.TWIG) + ")";
        }
        if (!creative) take(sp, StructureHealth.TWIG, units);

        ServerLevel sl = sp.serverLevel();
        for (BlockPos b : plan.blocks()) {
            sl.setBlock(b, ModBlocks.building(StructureHealth.TWIG).defaultBlockState(), 3);
        }
        BuildingData.Piece piece = BuildingData.get(sl).add(sp.getUUID(), k.ordinal(), StructureHealth.TWIG, plan.blocks());
        piece.placed = sl.getGameTime();
        sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.WOOD_PLACE, SoundSource.BLOCKS, 1.0F, 0.8F);
        return null;
    }
}
