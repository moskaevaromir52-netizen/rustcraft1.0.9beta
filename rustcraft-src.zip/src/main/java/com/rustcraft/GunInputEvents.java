package com.rustcraft;

import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** С оружием в руках ЛКМ - только выстрел: не ломаем блоки и не бьём врукопашную. */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GunInputEvents {
    private GunInputEvents() {
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (e.getItemStack().getItem() instanceof GunItem) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent e) {
        if (e.getEntity().getMainHandItem().getItem() instanceof GunItem) e.setCanceled(true);
    }
}
