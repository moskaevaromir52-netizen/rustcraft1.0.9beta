package com.rustcraft;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Гранаты и заряды: бросаются, взрываются по таймеру (см. {@link Fuses}). */
public class ThrowableExplosive extends Item {

    public enum Kind {
        F1(60, 3.0F),
        BEANCAN(40, 2.0F),
        SATCHEL(100, 4.5F),
        C4(160, 7.0F),
        MOLOTOV(25, 0.0F);

        public final int fuse;
        public final float power;

        Kind(int fuse, float power) {
            this.fuse = fuse;
            this.power = power;
        }
    }

    private final Kind kind;

    public ThrowableExplosive(Properties props, Kind kind) {
        super(props);
        this.kind = kind;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel sl) {
            Vec3 look = player.getLookAngle();
            Vec3 eye = player.getEyePosition();
            ItemEntity e = new ItemEntity(sl, eye.x + look.x * 0.4, eye.y - 0.2 + look.y * 0.4,
                    eye.z + look.z * 0.4, new ItemStack(this));
            double speed = (kind == Kind.SATCHEL || kind == Kind.C4) ? 0.5 : 1.0;
            e.setDeltaMovement(look.scale(speed).add(player.getDeltaMovement().x, 0.1, player.getDeltaMovement().z));
            e.setPickUpDelay(32767); // нельзя подобрать
            e.setUnlimitedLifetime();
            e.setInvulnerable(true);
            sl.addFreshEntity(e);
            Fuses.add(e, kind, player.getUUID());
            sl.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SNOWBALL_THROW,
                    SoundSource.PLAYERS, 0.8F, 0.6F);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
