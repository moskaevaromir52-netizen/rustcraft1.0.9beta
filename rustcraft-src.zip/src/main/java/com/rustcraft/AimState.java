package com.rustcraft;

import net.minecraft.client.Minecraft;

/** Прицеливание: ПКМ с оружием в руках (только клиент). */
public final class AimState {
    private AimState() {
    }

    public static boolean aiming() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && mc.screen == null && mc.options.keyUse.isDown()
                && mc.player.getMainHandItem().getItem() instanceof GunItem;
    }
}
