package com.rustcraft;

import java.util.Map;

/** Высота прицельной линии и масштаб модели в руке (генерируется). */
public final class GunSights {
    private GunSights() {
    }

    private static final Map<String, float[]> DATA = Map.ofEntries(
            Map.entry("eoka_pistol", new float[]{2.20F, 0.840F}),
            Map.entry("waterpipe_shotgun", new float[]{1.00F, 0.630F}),
            Map.entry("revolver", new float[]{1.60F, 0.840F}),
            Map.entry("python_revolver", new float[]{1.60F, 0.770F}),
            Map.entry("semi_auto_pistol", new float[]{1.50F, 0.840F}),
            Map.entry("m92_pistol", new float[]{1.50F, 0.812F}),
            Map.entry("prototype_17", new float[]{1.50F, 0.770F}),
            Map.entry("nailgun", new float[]{2.00F, 0.700F}),
            Map.entry("double_barrel_shotgun", new float[]{1.20F, 0.630F}),
            Map.entry("pump_shotgun", new float[]{1.30F, 0.588F}),
            Map.entry("spas12", new float[]{2.60F, 0.588F}),
            Map.entry("m4_shotgun", new float[]{1.60F, 0.532F}),
            Map.entry("custom_smg", new float[]{1.80F, 0.700F}),
            Map.entry("thompson", new float[]{1.80F, 0.644F}),
            Map.entry("mp5a4", new float[]{1.80F, 0.644F}),
            Map.entry("semi_auto_rifle", new float[]{3.20F, 0.560F}),
            Map.entry("m39_rifle", new float[]{1.60F, 0.532F}),
            Map.entry("lr300", new float[]{1.60F, 0.560F}),
            Map.entry("assault_rifle", new float[]{1.80F, 0.560F}),
            Map.entry("bolt_action_rifle", new float[]{2.20F, 0.490F}),
            Map.entry("l96_rifle", new float[]{2.20F, 0.462F}),
            Map.entry("m249", new float[]{2.00F, 0.504F}),
            Map.entry("hmlmg", new float[]{2.00F, 0.504F}),
            Map.entry("rocket_launcher", new float[]{3.40F, 0.476F}),
            Map.entry("mgl", new float[]{2.40F, 0.560F}),
            Map.entry("flamethrower", new float[]{1.80F, 0.532F}));

    public static float[] get(String id) {
        float[] f = DATA.get(id);
        return f == null ? new float[]{3.0F, 0.5F} : f;
    }
}
