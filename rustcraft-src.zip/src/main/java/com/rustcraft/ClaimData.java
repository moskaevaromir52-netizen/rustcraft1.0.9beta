package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Хранит приваты (шкафы) мира. */
public class ClaimData extends SavedData {
    public static final int RADIUS = 20;

    public static class Claim {
        public final UUID owner;
        public final String ownerName;
        public final Set<UUID> auth = new HashSet<>();

        public Claim(UUID owner, String ownerName) {
            this.owner = owner;
            this.ownerName = ownerName;
        }

        public boolean allows(UUID id) {
            return owner.equals(id) || auth.contains(id);
        }
    }

    private final Map<Long, Claim> claims = new HashMap<>();

    public static ClaimData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(ClaimData::load, ClaimData::new, "rustcraft_claims");
    }

    public void add(BlockPos pos, UUID owner, String name) {
        claims.put(pos.asLong(), new Claim(owner, name));
        setDirty();
    }

    public void remove(BlockPos pos) {
        if (claims.remove(pos.asLong()) != null) setDirty();
    }

    public Claim exact(BlockPos pos) {
        return claims.get(pos.asLong());
    }

    /** Первый приват, накрывающий точку. */
    public Claim at(BlockPos pos) {
        for (Map.Entry<Long, Claim> e : claims.entrySet()) {
            if (covers(BlockPos.of(e.getKey()), pos)) return e.getValue();
        }
        return null;
    }

    /** Приват игрока, накрывающий точку (при пересечении привотов берём именно его). */
    public Claim ownedAt(BlockPos pos, UUID owner) {
        for (Map.Entry<Long, Claim> e : claims.entrySet()) {
            if (e.getValue().owner.equals(owner) && covers(BlockPos.of(e.getKey()), pos)) return e.getValue();
        }
        return null;
    }

    public boolean canBuild(BlockPos pos, UUID id) {
        for (Map.Entry<Long, Claim> e : claims.entrySet()) {
            if (covers(BlockPos.of(e.getKey()), pos) && !e.getValue().allows(id)) return false;
        }
        return true;
    }

    private static boolean covers(BlockPos c, BlockPos p) {
        return Math.abs(c.getX() - p.getX()) <= RADIUS
                && Math.abs(c.getY() - p.getY()) <= RADIUS
                && Math.abs(c.getZ() - p.getZ()) <= RADIUS;
    }

    public static ClaimData load(CompoundTag tag) {
        ClaimData data = new ClaimData();
        ListTag list = tag.getList("claims", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            Claim claim = new Claim(c.getUUID("owner"), c.getString("name"));
            ListTag auth = c.getList("auth", Tag.TAG_COMPOUND);
            for (int j = 0; j < auth.size(); j++) {
                claim.auth.add(auth.getCompound(j).getUUID("id"));
            }
            data.claims.put(c.getLong("pos"), claim);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<Long, Claim> e : claims.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putLong("pos", e.getKey());
            c.putUUID("owner", e.getValue().owner);
            c.putString("name", e.getValue().ownerName);
            ListTag auth = new ListTag();
            for (UUID id : e.getValue().auth) {
                CompoundTag a = new CompoundTag();
                a.putUUID("id", id);
                auth.add(a);
            }
            c.put("auth", auth);
            list.add(c);
        }
        tag.put("claims", list);
        return tag;
    }
}
